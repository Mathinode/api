const mongoose=require("mongoose");
const InvoiceSchema=mongoose.Schema({
    InvNo:{type:String,required:true},
    serialNo:{type:String,required:true,default:0001},
    OrderID:{type:String,required:true}
},{timestamps:true});
module.exports=mongoose.model("Invoice",InvoiceSchema); 