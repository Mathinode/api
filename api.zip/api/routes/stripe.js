const StripeRouter=require("express").Router();
const stripe=require("stripe")(process.env.STRIPE_KEY);
const bodyParser = require('body-parser');
var jsonParser = bodyParser.json();
StripeRouter.post("/payment",jsonParser,(req,res)=>
{
   
stripe.charges.create({
    source:req.body.token,
    amount:req.body.amount,
    currency:"sgd",
},(stripeErr,stripeRes)=>
{
if(stripeErr)
{
    console.log(stripeErr);
    res.status(500).json(stripeErr);
}
else
{
    res.status(200).json(stripeRes);
}
});
});

module.exports=StripeRouter;