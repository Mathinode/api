const OrderRouter=require("express").Router();
const {verifyToken,verifyTokenAndAuthorization, verifyTokenAndAdmin}=require("./verifyToken");
const Order=require("../models/Order");
const bodyParser = require('body-parser');
var jsonParser = bodyParser.json();
const Invoice = require("../models/invoice");
const User = require("../models/User");
const { createInvoice } = require('./createInvoice.js');
const date = require('date-and-time');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'mathiapmasia@gmail.com',
      pass: 'qxmefyigpvuebuhc'
    }
  });

OrderRouter.post("/addtoOrder",verifyToken,jsonParser,async(req,res)=>
{
    const newOrder=new Order(req.body);
   
try{

      const savedOrder=await newOrder.save(); 
      res.status(200).json(savedOrder);
      console.log(savedOrder);
      const oldInvNo = await Invoice
      .find().limit(1).sort({$natural:-1}); 
      if(oldInvNo.length > 0)
      {
       newInvNo = parseInt(oldInvNo[0].serialNo)+ 1; 

    }
    else
    {
       newInvNo = '0001';
    }

      const newInvoice = new Invoice({
        InvNo:'INV_'+newInvNo,
        OrderID:savedOrder._id,
        serialNo:parseInt(oldInvNo[0].serialNo)+1
      });
      
      const newInv=await newInvoice.save(); 
      const  invoice_nr = newInv.InvNo;
      const user=await User.findById(savedOrder.userId);

      const items=savedOrder.products;
      const invoice = {
        shipping: {
          name: user.username,
          address: user.Address,
          city: user.Country,
          state: user.Country,
          country: user.Country,
          postal_code: 941111,
          inv_date:date.format(newInv.createdAt,'DD/MM/YYYY')
        },
        items: items,
        subtotal: 'S$ '+savedOrder.amount,
        paid: 0,
        invoice_nr:invoice_nr
      };
      createInvoice(invoice, "invoices/"+invoice_nr+".pdf");
      var mailOptions = {
        from: 'mathiapmasia@gmail.com',
        to: user.email,
        subject: 'Order Confirmation',
        text: 'Your order has been completed',
        attachments:{
            path:'invoices/'+invoice_nr+".pdf"
        }
      }
      
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
}
catch(err)
{
    console.log(err);
    res.status(500).json(err);
}
});
OrderRouter.put("/:id",verifyTokenAndAdmin,jsonParser,async(req,res)=>
{
try{
const updatedOrder=await Order.findByIdAndUpdate(req.params.id,
    {$set:req.body},
    {new:true});
    res.status(200).json(updatedOrder);
}
catch(err)
{
res.status(500).json(err);
}
});
OrderRouter.delete("/:id",verifyTokenAndAdmin,jsonParser,async(req,res)=>
{
try{
    await Order.findByIdAndDelete(req.params.id);
    res.status(200).json("Order has been deleted successfully");
}
catch(err)
{
    res.status(500).json(err);
}
});

OrderRouter.get("/:userId",verifyTokenAndAuthorization,jsonParser,async(req,res)=>
{
try{
    const orders=await Order.find({userID:req.params.userId});
    res.status(200).json(orders);
}
catch(err)
{
res.status(500).json(err);
}

});

OrderRouter.get("/",verifyTokenAndAdmin,jsonParser,async(req,res)=>
{
try{
    const orders=await Order.find();
    
    res.status(200).json(orders);
}
catch(err)
{
res.status(500).json(err);
}

});
module.exports=OrderRouter;