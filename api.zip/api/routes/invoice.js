const {verifyToken,verifyTokenAndAuthorization, verifyTokenAndAdmin}=require("./verifyToken");
const Invoice = require("../models/invoice");
const bodyParser = require('body-parser');
var jsonParser = bodyParser.json();
const InvoiceRouter=require("express").Router();

InvoiceRouter.get("/:orderId",verifyTokenAndAdmin,jsonParser,async(req,res)=>
{

  try{
    const invoice_data=await Invoice.find({OrderID:req.params.orderId});
   
    res.status(200).json(invoice_data);
}
catch(err)
{
res.status(500).json(err);
}
});
module.exports=InvoiceRouter;