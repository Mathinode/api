const AuthRouter=require("express").Router();
const bodyParser = require('body-parser');
var jsonParser = bodyParser.json()
const User=require("../models/User");
const CryptoJS = require("crypto-js");
const jwt=require("jsonwebtoken");
AuthRouter.post("/register",jsonParser,async(req,res)=>
{
   
let isAdmin = true;
if(req.body.isAdmin=="True")
{
    isAdmin = true;
}   
else
{
    isAdmin = false;  
}
const newUser=new User({
username:req.body.username,
email:req.body.email,
isAdmin:isAdmin,
password:CryptoJS.AES.encrypt(req.body.password,process.env.SECRET_KEY).toString(),
Address:req.body.Address,
Country:req.body.Country
});
try
{
    const savedUser=await newUser.save();
    res.status(200).send(savedUser);
}
catch(err)
{
    res.status(404).send(err); 
}
});

AuthRouter.post("/login",jsonParser,async(req,res)=>
{
const password=req.body.password;  
try{
    const user=await User.findOne({username:req.body.username});
    if(!user)
    {
        res.status(404).send("Wrong Credentials");
    }
    else
    {
    var hashedPassword = CryptoJS.AES.decrypt(user.password, process.env.SECRET_KEY);
    const  password1=hashedPassword.toString(CryptoJS.enc.Utf8);
    if( password1 !=req.body.password )
    {
        res.status(404).send("Wrong credential");
    }

   else
   {
   const accessToken= jwt.sign({
        userId:user._id,
        isAdmin:user.isAdmin
    },process.env.JWT_KEY,{expiresIn:'3d'})
    const { password, ...others } = user._doc;
    res.status(200).send({...others,accessToken:accessToken});
}
}   
}  
catch(err)
{
    res.status(404).send(err);
}

});

module.exports=AuthRouter;